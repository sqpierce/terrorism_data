
#proc areadef
rectangle: 3 4 6 7
xrange: 0 10
yrange: 0 10
frame: yes
